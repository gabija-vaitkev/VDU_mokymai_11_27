################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

######################
# Neporinis t-testas #
######################
?PlantGrowth
View(PlantGrowth)
head(PlantGrowth)

# Išsirenkame tik dvi grupes - kontrolę ir trt1
subset2 <- subset(PlantGrowth, group %in% c("ctrl", "trt2"))

# Atsiskiriame grupes, nes jose
# Tikrinsime duomenų normalumą
ctrl <- subset(subset2, subset2$group == "ctrl")
trt2 <- subset(subset2, subset2$group == "trt2")

# Vizualizuojame duomenis:
if (!require("ggplot2")) install.packages("ggplot2")
library(ggplot2)

ggplot(subset2, aes(x = group, y = weight, fill = group)) +
  geom_boxplot(
    width = 0.5,
    alpha = 0.6,
    outlier.shape = NA
  ) +
  geom_jitter(
    width = 0.08,
    size = 2,
    alpha = 0.8
  ) +
  scale_fill_manual(
    values = c("ctrl" = "#0072B2", "trt2" = "#D55E00")
  ) +
  labs(
    title = "Plant weight comparison",
    x = "Group",
    y = "Weight"
  ) +
  theme_classic(base_size = 14) +
  theme(legend.position = "none")

# Pasitikriname duomenų normalumą
shapiro.test(ctrl$weight)
shapiro.test(trt2$weight)

# Pasitikriname dispersijų homogeniškumą
if (!require("car")) install.packages("car")
library(car)
leveneTest(weight ~ group, data = subset2)

# T-testas taikomas tada kai duomenys pasiskirstę normaliai
# ir dispersijos homogeniškos
t.test(weight ~ group, data = subset2, var.equal = TRUE)

# Kai duomenys pasiskirstę normaliai,
# bet dispersijos nehomogeniškos
# taikomas T-testas su Welch korekcija
t.test(weight ~ group, data = subset2, var.equal = FALSE)

# Wilcoxon (Mann-Whitney U) testas taikomas
# kai duomenys nėra pasiskirstę normaliai
wilcox.test(weight ~ group, data = subset2)

####################
# Porinis t-testas #
####################
?sleep
View(sleep)
head(sleep)

# Vizualizuojame duomenis
ggplot(sleep, aes(x = group, y = extra, fill = group)) +
  geom_boxplot(alpha = 0.6, width = 0.5, outlier.shape = NA) +
  geom_jitter(width = 0.1, size = 2, alpha = 0.9) +
  labs(
    title = "Increase in sleep by drug",
    x = "Group",
    y = "Extra hours of sleep"
  ) +
  theme_bw(base_size = 14) +
  scale_fill_manual(values = c("1" = "#7bc043", "2" = "#0392cf")) +
  theme(legend.position = "none")

# Išrikiuojame duomenis pagal ID
sleep_sorted <- sleep[order(sleep$ID, sleep$group), ]

# Atskiriame kiekvieno paciento matavimus
extra_1 <- sleep_sorted$extra[sleep_sorted$group == "1"]
extra_2 <- sleep_sorted$extra[sleep_sorted$group == "2"]

# Skirtumai (2 grupė - 1 grupė)
differences <- extra_2 - extra_1
differences

# Patikriname skirtumų duomenų normalumą vizualiai
hist(
  differences,
  main = "Skirtumų pasiskirstymas",
  xlab = "Skirtumas (2 grupė – 1 grupė)",
  col = "lightblue"
)

# qqplot
qqnorm(differences)
qqline(differences)

# Patikriname normalumą su statistiniu testu
shapiro.test(differences)

# Jei skirtumų duomenys pasiskirstę normaliai
# Paruošiame duomenis analizei
sleep2 <- reshape(sleep, direction = "wide",
                  idvar = "ID", timevar = "group")
sleep2

# Atliekame porinį t-testą
t.test(Pair(extra.1, extra.2) ~ 1, data = sleep2)

# Jei skirtumų duomenys nėra pasiskirstę normaliai
# Atliekame Wilcoxon testą
wilcox.test(Pair(extra.1, extra.2) ~ 1, data = sleep2)
