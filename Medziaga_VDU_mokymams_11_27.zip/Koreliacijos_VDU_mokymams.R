################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

#########################################
##### Paprastų koreliacijų pavyzdys #####
# Užkrauname "built-in" duomenų rinkinį #
#########################################
data(iris)
View(iris)

# Sukuriame pogrupius
iris_setosa <- subset(iris, Species == "setosa")
iris_versicolor <- subset(iris, Species == "versicolor")
iris_virginica <- subset(iris, Species == "virginica")

# Patikriname duomenų normalumą pogrupiuose
shapiro.test(iris_setosa$Petal.Length)
shapiro.test(iris_versicolor$Petal.Length)
shapiro.test(iris_virginica$Petal.Length)

shapiro.test(iris_setosa$Petal.Width)
shapiro.test(iris_versicolor$Petal.Width)
shapiro.test(iris_virginica$Petal.Width)

shapiro.test(iris_setosa$Sepal.Length)
shapiro.test(iris_versicolor$Sepal.Length)
shapiro.test(iris_virginica$Sepal.Length)

shapiro.test(iris_setosa$Sepal.Width)
shapiro.test(iris_versicolor$Sepal.Width)
shapiro.test(iris_virginica$Sepal.Width)

# Atliekame koreliacijos testus tarp žiedlapių ilgio ir pločio
# Galite pridėti ir savo testus - taip palyginti ir kitus kintamuosius tarpusavyje (pvz., taurėlapių ilgį ir plotį)
cor_setosa <- cor.test(
  iris_setosa$Petal.Length,
  iris_setosa$Petal.Width,
  method = "spearman"
)
cor_setosa

cor_versicolor <- cor.test(
  iris_versicolor$Petal.Length,
  iris_versicolor$Petal.Width,
  method = "spearman"
)
cor_versicolor

cor_virginica <- cor.test(
  iris_virginica$Petal.Length,
  iris_virginica$Petal.Width,
  method = "pearson"
)
cor_virginica

##########################################################
# Brėžiame sklaidos diagramas atskirai kiekvienai rūšiai #
##########################################################

# Perspėjimas - tam, kad diagramų kodas veiktų,
# Prieš tai turi būti praleistas anksčiau esantis koreliacijų kodas
if (!require("ggplot2")) install.packages("ggplot2")
if (!require("dplyr")) install.packages("dplyr")

library(ggplot2)
library(dplyr)

# Sukuriame nurodymus koreliacinėms analizėms
cor_labels <- iris %>%
  group_by(Species) %>%
  reframe({
    m <- if (Species[1] == "virginica") "pearson" else "spearman"
    
    test <- if (m == "spearman") {
      cor.test(Petal.Length, Petal.Width, method = m, exact = FALSE)
    } else {
      cor.test(Petal.Length, Petal.Width, method = m)
    }
    
    data.frame(
      label = paste0(
        tools::toTitleCase(m),
        "\nr = ", round(test$estimate, 2),
        "\np = ", signif(test$p.value, 3)
      )
    )
  })

###############################################
# Atskiros diagramos visoms vilkdalgių rūšims #
###############################################

# Sukuriame trijų dalių diagramą ("facet")
p1 <- ggplot(iris, aes(Petal.Length, Petal.Width, color = Species)) +
  geom_point(size = 2.5, alpha = 0.8) +
  geom_smooth(method = "lm", se = FALSE, color = "black", linewidth = 0.8) +
  geom_text(
    data = cor_labels,
    aes(label = label),
    x = -Inf, y = Inf, hjust = -0.1, vjust = 1.15,
    inherit.aes = FALSE, size = 3.8
  ) +
  facet_wrap(~ Species, scales = "free") +
  scale_color_manual(values = c(
    "setosa" = "#D55E00", 
    "versicolor" = "#009E73", 
    "virginica" = "#0072B2"
  )) +
  theme_bw(base_size = 13) +
  theme(legend.position = "none") +
  labs(
    title = "Correlations in separate Iris species",
    x = "Petal Length", 
    y = "Petal Width"
  )

p1

############################################
# Bendra diagrama visoms vilkdalgių rūšims #
############################################

# Nurodome teksto poziciją bendrame grafike
cor_labels$y_pos <- c(2.4, 1.8, 1.2)

# Sukuriame diagramą
p2 <- ggplot(iris, aes(Petal.Length, Petal.Width, color = Species)) +
  geom_point(size = 2.5, alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE, linewidth = 1) +
  scale_color_manual(values = c(
    "setosa" = "#D55E00", 
    "versicolor" = "#009E73", 
    "virginica" = "#0072B2"
  )) +
  geom_text(
    data = cor_labels,
    aes(x = min(iris$Petal.Length), y = y_pos, label = label, color = Species),
    hjust = 0, lineheight = 0.9, size = 3.8, show.legend = FALSE
  ) +
  theme_bw(base_size = 14) +
  labs(
    title = "Bendra sklaidos diagrama",
    x = "Petal Length", 
    y = "Petal Width", 
    color = "Species"
  )

p2

#######################################
# Koreliacijų matricos pavyzdys #######
# Užkrauname built-in duomenų rinkinį #
#######################################
View(mtcars)
data(mtcars)
str(mtcars)

# Patikriname duomenų normalumą
shapiro.test(mtcars$mpg)
shapiro.test(mtcars$cyl)
shapiro.test(mtcars$disp)
shapiro.test(mtcars$hp)
shapiro.test(mtcars$drat)
shapiro.test(mtcars$wt)
shapiro.test(mtcars$qsec)
shapiro.test(mtcars$vs)
shapiro.test(mtcars$am)
shapiro.test(mtcars$gear)
shapiro.test(mtcars$carb)

# Atliekame statistinius testus ir sukuriam koreliacjų matricą
cor_matrix <- cor(
  mtcars,
  method = "spearman"
)

cor_matrix_rounded <- round(cor_matrix, 3) # < - rezultatai suapvalinami iki 3 skaičių po kablelio
cor_matrix_rounded

# Naudojame write.csv funkciją tam, kad išsisaugotume rezultatus:
# (prisiminkite, kur jūsų darbinė direktorija - nusistatykite ją)
setwd("C:/Users/gabij/Documents/Biomatika/Mokymai/VDU_2026_11_20")
getwd()

write.csv(cor_matrix_rounded, "correlation_matrix_rho.csv", row.names = TRUE)

# p reikšmių koreliacijų matrica
cor_pvalues <- function(mat) {
  n <- ncol(mat)
  p_mat <- matrix(NA, n, n)
  colnames(p_mat) <- colnames(mat)
  rownames(p_mat) <- colnames(mat)
  
  for (i in 1:n) {
    for (j in 1:n) {
      test <- cor.test(mat[, i], mat[, j], method = "spearman")
      p_mat[i, j] <- test$p.value
    }
  }
  p_mat
}

p_matrix <- cor_pvalues(mtcars)

p_matrix_rounded <- round(p_matrix, 3)
p_matrix_rounded

# Naudojame write.csv funkciją tam, kad išsisaugotume rezultatus:
# (prisiminkite, kur jūsų darbinė direktorija - nusistatykite ją)
write.csv(p_matrix, "correlation_matrix_p_full.csv", row.names = TRUE)
write.csv(p_matrix_rounded, "correlation_matrix_p_rounded.csv", row.names = TRUE)

# Koreliacijų matricos  vizualizacija
# 1. pilna koreliacijų matrica - rodomi visi rezultatai
if (!require("corrplot")) install.packages("corrplot")
library(corrplot)

corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  tl.col = "black",
  addCoef.col = "black",
  number.cex = 1
)

# 2. Pakoreguota koreliacijų matrica - rodomi tik
# statistiškai reikšmingi rezultatai
corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  tl.col = "black",
  addCoef.col = "black", # arba "white"
  number.cex = 1,
  p.mat = p_matrix,
  sig.level = 0.05,
  insig = "blank"
)

# 3. Pakoreguota koreliacijų matrica - išmetame
# įstrižainę, kur kintamieji lyginami patys su savimi
# užrašome reikšmes balta spalva
corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  tl.col = "black",
  addCoef.col = "white",
  number.cex = 1,
  p.mat = p_matrix,
  sig.level = 0.05,
  insig = "blank",
  diag = FALSE
)
