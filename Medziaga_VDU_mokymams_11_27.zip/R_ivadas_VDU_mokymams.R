################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

################################
# 1 DALIS - susipažinkime su R #
################################

# Matematiniai ir loginiai uždaviniai programos pratestavimui
2 + 2
4 ^ 4
2 < 3
4 != 5

###################################
# 2 DALIS - aprašomoji statistika #
###### ir duomenų normalumas ######
###################################

# Kodinis darbinio aplanko nustatymas (reikia suvesti kelią į savo darbinį aplanką):
setwd("C:/Users/X/Documents/.../Jusu_aplankas")

# Norint patikrinti darbinę direktoriją, naudojame:
getwd()

# I DUOMENŲ ĮSIKĖLIMO BŪDAS ("VARTOTOJUI DRAUGIŠKAS")
# 1. Dokumento įsikėlimas: File -> Import Dataset -> From Text (base)

# 2. Pervadiname duomenis (jei duomenis įsikėlėme "Vartotojui draugišku" būdu)
zuvys1 <- zuvu_ilgis_1 
zuvys2 <- zuvu_ilgis_2

# II DUOMENŲ ĮSIKĖLIMO BŪDAS
# Kodu grįstas duomenų įkėlimo būdas,
# kuris yra naudingas ateityje norint išsaugoti,
# pakartoti ar automatizuoti analizes;
# 1. Nurodoma dokumento direktorija ir užkraunamas dokumentas:
zuvys1 <- read.csv("C:/Users/gabij/Documents/Biomatika/Mokymai/VDU_2026_11_20/zuvu_ilgis_1.csv", 
                   header=TRUE, sep = ",", stringsAsFactors=T)

zuvys2 <- read.csv("C:/Users/gabij/Documents/Biomatika/Mokymai/VDU_2026_11_20/zuvu_ilgis_2.csv", 
                   header=TRUE, sep = ",", stringsAsFactors=T)

# Peržiūrime duomenų santrauką (pirmos 6 eilutės):
head(zuvys1)
head(zuvys2)

# Peržiūrime duomenis lentelėse
View(zuvys1)
View(zuvys2)

# Stulpelių pavadinimai
names(zuvys1)
names(zuvys2)

# Vidurkis
mean(zuvys1$ilgis_cm)
mean(zuvys2$ilgis_cm)

# Mediana
median(zuvys1$ilgis_cm)
median(zuvys2$ilgis_cm)

# Standartinis nuokrypis
sd(zuvys1$ilgis_cm)
sd(zuvys2$ilgis_cm)

# Kitos aprašomosios statistikos funkcijos:
# min, max
min(zuvys1$ilgis_cm)
min(zuvys2$ilgis_cm)
max(zuvys1$ilgis_cm)
max(zuvys2$ilgis_cm)

# Histogramos 
par(mfrow = c(1,2))

hist(zuvys1$ilgis_cm, main = "Zuvys1", col = "lightblue")
hist(zuvys2$ilgis_cm, main = "Zuvys2", col = "lightpink")

# Q-Q diagramos
par(mfrow = c(1,2))

qqnorm(zuvys1$ilgis_cm, main = "Zuvys1 Q-Q diagrama")
qqline(zuvys1$ilgis_cm)

qqnorm(zuvys2$ilgis_cm, main = "Zuvys2 Q-Q diagrama")
qqline(zuvys2$ilgis_cm)

# Shapiro-Wilk testas normalumui patikrinti
# Jei p reikšmė < 0,05, duomenys nėra pasiskirstę normaliai
shapiro.test(zuvys1$ilgis_cm)
shapiro.test(zuvys2$ilgis_cm)

######################################################
# 3 DALIS - vidurkių tarp 2 grupių palyginimo testai #
######################################################

# T-testas taikomas tada kai duomenys pasiskirstę normaliai
t.test(zuvys1$ilgis_cm, zuvys2$ilgis_cm, paired = FALSE)

# Wilcoxon (Mann-Whitney U) testas taikomas
# kai duomenys nėra pasiskirstę normaliai
wilcox.test(zuvys1$ilgis_cm, zuvys2$ilgis_cm, paired = FALSE)

##############################################
# 4 DALIS - grafinio vizualizavimo pagrindai #
##############################################

#########################################
# Pradedame nuo bazinio R vizualizacijų #
#########################################

# Nusistome 1 grafiko vaizdavimą vienu metu
par(mfrow=c(1,1))

# Duomenų rinkiniai, kuriuos naudosime:
# iris ir PlantGrowth
?iris
?PlantGrowth
View(iris)
View(PlantGrowth)

# Histograma
hist(iris$Sepal.Length, main="Taurėlapių ilgio pasiskirstymas", xlab="Ilgis (cm)")

# Stulpelinė diagrama
barplot(table(iris$Species), main="Mėginių kiekis pagal augalo rūšį", ylab="Kiekis")

# Dėžučių grafikas
boxplot(weight ~ group, data=PlantGrowth,
        main="Augalų sausa masė pagal grupes", xlab="Grupė", ylab="Svoris (g)")

# Sklaidos diagrama
plot(iris$Sepal.Length, iris$Petal.Length,
     col = c("red", "green", "blue")[iris$Species],
     pch = 19,
     main = "Ryšys tarp žiedlapių ir taurėlapių ilgio",
     xlab = "Taurėlapio ilgis (cm)",
     ylab = "Žiedlapio ilgis (cm)")

# Pridedame legendą
legend("topleft",
       legend = levels(iris$Species),
       col = c("red", "green", "blue"),
       pch = 19)

#####################################
###### Pereiname prie ggplot2 #######
##### Jei naudojame pirmą kartą #####
########## Reikia sudiegti ##########
#### install.packages("ggplot2") ####
##### diegiama tik vieną kartą ######
# užkraunama kaskart pradėjus darbą #
######### library(ggplot2) ##########
#####################################

library(ggplot2)

# Histograma su ggplot2
ggplot(iris, aes(x = Sepal.Length)) +
  geom_histogram(
    binwidth = 0.3,         # control bar width
    fill = "#D3D3FF",       # custom color
    color = "black"
  ) +
  labs(
    title = "Taurėlapių ilgio pasiskirstymas",
    x = "Taurėlapio ilgis (cm)",
    y = "Dažnis"
  ) +
  theme_minimal(base_size = 16)

# Stulpelinė diagrama su ggplot2
ggplot(iris, aes(x = Species, fill = Species)) +
  geom_bar(color = "black") +
  scale_fill_manual(values = c("#D3D3FF", "#C9F2C7", "#FFD6C9")) +
  labs(
    title = "Mėginių kiekis pagal augalo rūšį",
    x = "Rūšis",
    y = "Kiekis"
  ) +
  theme_minimal(base_size = 16) +
  theme(legend.position = "none")

# Dėžučių grafikas su ggplot2
ggplot(PlantGrowth, aes(x = group, y = weight, fill = group)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = c("#D3D3FF", "#C9F2C7", "#FFD6C9")) +
  labs(
    title = "Augalų svoris pagal grupes",
    x = "Grupė",
    y = "Svoris (g)"
  ) +
  theme_minimal(base_size = 16) +
  theme(legend.position = "none")

# Sklaidos diagrama su ggplot2
ggplot(iris, aes(x = Sepal.Length, y = Petal.Length, color = Species)) +
  geom_point(size = 3) +
  labs(
    title = "Ryšys tarp žiedlapių ir taurėlapių ilgio",
    x = "Taurėlapio ilgis (cm)",
    y = "Žiedlapio ilgis (cm)"
  ) +
  theme_minimal(base_size = 16)
