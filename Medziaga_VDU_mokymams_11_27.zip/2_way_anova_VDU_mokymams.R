################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

# Peržiūrime duomenis
View(ToothGrowth)
?ToothGrowth

my_data <- ToothGrowth
my_data

# Patikriname duomenų struktūrą
str(my_data)

# Konvertuojame dozę kaip faktorių ir rekoduojame lygius (levels)
# kaip "D0.5", "D1", "D2"
my_data$dose <- factor(my_data$dose, 
                       levels = c(0.5, 1, 2),
                       labels = c("D0.5", "D1", "D2"))
head(my_data)

# Dėžučių diagrama su keliomis grupėmis
# Tooth length ("len") pagal grupes ("dose")
# Parenkame spalvas pagal antrą nepriklausomą kintamąjį: "supp"
library(ggplot2)

ggplot(my_data, aes(x = dose, y = len, fill = supp)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) +
  labs(x = "dose", y = "len", fill = "supp") +
  theme_minimal(base_size = 14)

# Linijinės diagramos su keliomis grupėmis
# Brėžiame tooth length ("len") pagal grupes ("dose")
# Spalvos parenkamos pagal antrą nepriklausomą kintamąjį: "supp"
# Pridedame paklaidos ūselius: mean_se
# (kiti galimi variantai: mean_sd, mean_ci, median_iqr, ....)
library(ggplot2)

ggplot(my_data, aes(x = dose, y = len, group = supp, color = supp)) +
  # "žali" duomenys (sklaidos diagramos atitikmuo)
  geom_jitter(width = 0.1, alpha = 0.6) +
  # vidurkio linija
  stat_summary(fun = mean, geom = "line", linewidth = 1) +
  # vidurkių taškai
  stat_summary(fun = mean, geom = "point", size = 3) +
  # vidurkis ± SE
  stat_summary(fun.data = mean_se, geom = "errorbar", width = 0.1) +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) +
  labs(x = "dose", y = "len", color = "supp") +
  theme_minimal(base_size = 14)

# Norime sužinoti ar tooth length priklauso nuo supp ir dose
# Pridedamasis (additive) modelis
# Kuris daro prielaidą, kad abu nepriklausomi kintamieji nedaro įtakos vienas kitam
res.aov2 <- aov(len ~ supp + dose, data = my_data)
summary(res.aov2)

# Jeigu yra galimybė, kad nepriklausomi kintamieji gali sąveikauti
# ir sukurti sinergistinį efektą, pliuso ženklą (+) 
# keičiame žvaigždutės simboliu (*)
# Taip atliekame dviejų veiksnių ANOVĄ su sąveikomis
res.aov3 <- aov(len ~ supp * dose, data = my_data)
summary(res.aov3)

# Matome, kad abu nepriklausomi kintamieji (supp ir dose) turi
# statistiškai reikšmingą poveikį priklausmam kintamajam (len)
# ir jų sąveika taip pat turi statistiškai reikšmingą poveikį kintamajam len
library(dplyr)

# Aprašomoji statistika (santrauka)
descriptives <- group_by(my_data, supp, dose) %>%
  summarise(
    count = n(),
    mean = mean(len, na.rm = TRUE),
    sd = sd(len, na.rm = TRUE)
  )

descriptives

TukeyHSD(res.aov3, which = "dose")

# post-hoc raidės
library(agricolae)

hsd_res2 <- HSD.test(res.aov3, "dose", group = TRUE)
hsd_res2
