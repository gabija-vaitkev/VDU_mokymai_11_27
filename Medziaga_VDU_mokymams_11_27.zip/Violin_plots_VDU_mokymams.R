################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

#################################
# Bendras violin plots pavyzdys #
#################################

# Užkrauname paketą
library(ggplot2)

# ===== PVZ 1: Viena smuiko diagrama =====
# Sukuriame sintetinius duomenis
set.seed(123)
data1 <- data.frame(
  category = rep(c("Group A", "Group B", "Group C"), each = 100),
  values = c(rnorm(100, mean = 50, sd = 10),
             rnorm(100, mean = 60, sd = 8),
             rnorm(100, mean = 55, sd = 12))
)

# Paprasta smuiko diagrama
ggplot(data1, aes(x = category, y = values, fill = category)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.1, fill = "white", outlier.shape = NA) +
  labs(title = "Distribution of Values Across Groups",
       x = "Category",
       y = "Values") +
  theme_minimal() +
  theme(legend.position = "none")


# ===== PVZ 2: Daugiau smuiko diagramų (2x2 tinklelis) =====
# Sukuriame sintetinius duomenis
set.seed(456)

# 1 duomenų rinkinys: Treatment vs Control
data_treatment <- data.frame(
  group = rep(c("Control", "Treatment"), each = 80),
  response = c(rnorm(80, mean = 100, sd = 15),
               rnorm(80, mean = 115, sd = 12))
)

# 2 duomenų rinkinys: Seasons
data_seasons <- data.frame(
  season = rep(c("Spring", "Summer", "Fall", "Winter"), each = 60),
  temperature = c(rnorm(60, mean = 15, sd = 5),
                  rnorm(60, mean = 25, sd = 4),
                  rnorm(60, mean = 12, sd = 6),
                  rnorm(60, mean = 2, sd = 7))
)

# 3 duomenų rinkinys: Age groups
data_age <- data.frame(
  age_group = rep(c("18-30", "31-50", "51-70"), each = 70),
  score = c(rnorm(70, mean = 75, sd = 10),
            rnorm(70, mean = 80, sd = 8),
            rnorm(70, mean = 70, sd = 12))
)

# 4 duomenų rinkinys: Product ratings
data_products <- data.frame(
  product = rep(c("Product A", "Product B"), each = 100),
  rating = c(rnorm(100, mean = 4.2, sd = 0.8),
             rnorm(100, mean = 3.8, sd = 1.0))
)

# Sukuriame individualius grafikus
plot1 <- ggplot(data_treatment, aes(x = group, y = response, fill = group)) +
  geom_violin(trim = FALSE, alpha = 0.6) +
  geom_boxplot(width = 0.1, fill = "white") +
  labs(title = "Treatment Effect", x = "", y = "Response") +
  theme_minimal() +
  theme(legend.position = "none")

plot2 <- ggplot(data_seasons, aes(x = season, y = temperature, fill = season)) +
  geom_violin(trim = FALSE, alpha = 0.6) +
  geom_boxplot(width = 0.1, fill = "white") +
  labs(title = "Seasonal Temperature", x = "", y = "Temperature (°C)") +
  theme_minimal() +
  theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))

plot3 <- ggplot(data_age, aes(x = age_group, y = score, fill = age_group)) +
  geom_violin(trim = FALSE, alpha = 0.6) +
  geom_boxplot(width = 0.1, fill = "white") +
  labs(title = "Scores by Age Group", x = "", y = "Score") +
  theme_minimal() +
  theme(legend.position = "none")

plot4 <- ggplot(data_products, aes(x = product, y = rating, fill = product)) +
  geom_violin(trim = FALSE, alpha = 0.6) +
  geom_boxplot(width = 0.1, fill = "white") +
  labs(title = "Product Ratings", x = "", y = "Rating (1-5)") +
  theme_minimal() +
  theme(legend.position = "none")

# Sukombinuojame grafikus 2x2 tinklelyje
# install.packages("patchwork") 
library(patchwork)

(plot1 | plot2) / (plot3 | plot4) +
  plot_annotation(title = "Multiple Violin Plots: Comparing Different Datasets",
                  theme = theme(plot.title = element_text(hjust = 0.5, size = 16)))

# Alternatyva: gridExtra paketas
library(gridExtra)
grid.arrange(plot1, plot2, plot3, plot4, ncol = 2,
             top = "Multiple Violin Plots: Comparing Different Datasets")


##################################
# Antras smuiko grafikų pavyzdys #
##################################

# Sukuriame sintetinius duomenis
set.seed(789)

years <- c(2022, 2023, 2024)
treatments <- c("Control", "NPK-Low", "NPK-High", "Organic")
n_plots <- 30

# Susintetinami derlingumo duomenys (t/ha)
yield_data <- data.frame()

for (year in years) {
  # Aplinkos veiksnys: 2023 buvo geri metai, 2022 buvo sausra
  year_effect <- ifelse(year == 2022, -0.5, ifelse(year == 2023, 0.8, 0))
  
  for (treatment in treatments) {
    # Skirtingos grupės
    treatment_effect <- switch(treatment,
                               "Control" = 0,
                               "NPK-Low" = 0.8,
                               "NPK-High" = 1.5,
                               "Organic" = 1.0)
    
    # Derlingumas su kintamumu
    base_yield <- 4.5
    yield <- rnorm(n_plots, 
                   mean = base_yield + treatment_effect + year_effect, 
                   sd = 0.6)
    
    temp_data <- data.frame(
      year = as.factor(year),
      treatment = factor(treatment, levels = treatments),
      yield = yield
    )
    
    yield_data <- rbind(yield_data, temp_data)
  }
}

# Pasižiūrime pirmas kelias eilutes
head(yield_data)
summary(yield_data)

# Sukuriame kombinuotus violin plots
ggplot(yield_data, aes(x = treatment, y = yield, fill = year)) +
  geom_violin(trim = FALSE, position = position_dodge(0.9), alpha = 0.7) +
  geom_boxplot(width = 0.15, position = position_dodge(0.9), 
               fill = "white", outlier.size = 1) +
  labs(title = "Wheat Yield Distribution by Fertilizer Treatment Across Years",
       subtitle = "Field trial data (2022-2024) - 30 plots per treatment per year",
       x = "Treatment",
       y = "Yield (tonnes/ha)",
       fill = "Year") +
  scale_fill_manual(values = c("#E69F00", "#56B4E9", "#009E73")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "right",
        plot.title = element_text(size = 14, face = "bold"),
        plot.subtitle = element_text(size = 10, color = "gray40"))

# Alternatyvi vizualizacija: "Faceted" pagal metus
ggplot(yield_data, aes(x = treatment, y = yield, fill = treatment)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.2, fill = "white", outlier.size = 1) +
  facet_wrap(~year, ncol = 3) +
  labs(title = "Wheat Yield Distribution by Treatment and Year",
       subtitle = "Each panel shows one year of the trial",
       x = "Treatment",
       y = "Yield (tonnes/ha)") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none",
        strip.text = element_text(size = 12, face = "bold"))

# Alternatyvi vizualizacija 2: atskiri grafikai tinklelyje
library(patchwork)

# Apskaičiuojame Y ašies ribas su maža atsarga smuiko (violin) uodegoms
y_limits <- range(yield_data$yield, na.rm = TRUE) + c(-0.8, 0.8)

# Sukuriame individualų grafiką kiekvieniems metams
plot_2022 <- ggplot(subset(yield_data, year == 2022), 
                    aes(x = treatment, y = yield, fill = treatment)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.2, fill = "white", outlier.size = 1) +
  labs(title = "2022 (Drought Year)",
       x = "",
       y = "Yield (tonnes/ha)") +
  coord_cartesian(ylim = y_limits) +  # Fiksuota Y ašis (limitai)
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none",
        plot.title = element_text(size = 12, face = "bold"))

plot_2023 <- ggplot(subset(yield_data, year == 2023), 
                    aes(x = treatment, y = yield, fill = treatment)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.2, fill = "white", outlier.size = 1) +
  labs(title = "2023 (Favorable Year)",
       x = "",
       y = "Yield (tonnes/ha)") +
  coord_cartesian(ylim = y_limits) +  # Fiksuota Y ašis
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none",
        plot.title = element_text(size = 12, face = "bold"))

plot_2024 <- ggplot(subset(yield_data, year == 2024), 
                    aes(x = treatment, y = yield, fill = treatment)) +
  geom_violin(trim = FALSE, alpha = 0.7) +
  geom_boxplot(width = 0.2, fill = "white", outlier.size = 1) +
  labs(title = "2024 (Normal Year)",
       x = "",
       y = "Yield (tonnes/ha)") +
  coord_cartesian(ylim = y_limits) +  # Fiksuota Y ašis
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "none",
        plot.title = element_text(size = 12, face = "bold"))

# Sukombinuojame į tinklelį (1 eilė x 3 stulpeliai)
(plot_2022 | plot_2023 | plot_2024) +
  plot_annotation(
    title = "Wheat Yield by Fertilizer Treatment: Three-Year Comparison",
    subtitle = "Each plot shows yield distribution for one growing season (n=30 plots per treatment)",
    theme = theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
                  plot.subtitle = element_text(size = 10, hjust = 0.5))
  )