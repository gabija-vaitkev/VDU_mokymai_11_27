################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

# Sukuriame sintetinius duomenis
set.seed(789)

years <- c(2022, 2023, 2024)
treatments <- c("Control", "NPK-Low", "NPK-High", "Organic")
n_plots <- 30

# Susintetinami derlingumo duomenys (t/ha)
yield_data <- data.frame()

for (year in years) {
  # Aplinkos veiksnys: 2023 buvo geri metai, 2022 buvo sausra
  year_effect <- ifelse(year == 2022, -0.5, ifelse(year == 2023, 0.8, 0))
  
  for (treatment in treatments) {
    # Skirtingos grupės
    treatment_effect <- switch(treatment,
                               "Control" = 0,
                               "NPK-Low" = 0.8,
                               "NPK-High" = 1.5,
                               "Organic" = 1.0)
    
    # Derlingumas su kintamumu
    base_yield <- 4.5
    yield <- rnorm(n_plots, 
                   mean = base_yield + treatment_effect + year_effect, 
                   sd = 0.6)
    
    temp_data <- data.frame(
      year = as.factor(year),
      treatment = factor(treatment, levels = treatments),
      yield = yield
    )
    
    yield_data <- rbind(yield_data, temp_data)
  }
}

# Pasižiūrime pirmas kelias eilutes
head(yield_data)
summary(yield_data)


################################
# Lentelės ir jų eksportavimas #
################################
# Aprašomoji statistika pagal grupes ir metus

summary_stats <- aggregate(yield ~ treatment + year, data = yield_data, 
                           FUN = function(x) c(mean = round(mean(x), 2), 
                                               median = round(median(x), 2),
                                               sd = round(sd(x), 2),
                                               min = round(min(x), 2),
                                               max = round(max(x), 2),
                                               n = length(x)))

# Pasižiūrime rezultatus
print(summary_stats)

# Eksportuojame rezultatus į Excel
# install.packages("writexl") 
library(writexl)

# Konvertuojame rezultatus į df (data frame)
summary_df <- data.frame(
  treatment = summary_stats$treatment,
  year = summary_stats$year,
  mean = summary_stats$yield[, "mean"],
  median = summary_stats$yield[, "median"],
  sd = summary_stats$yield[, "sd"],
  min = summary_stats$yield[, "min"],
  max = summary_stats$yield[, "max"],
  n = summary_stats$yield[, "n"]
)

# Eksportuojame į Excel failą
write_xlsx(summary_df, "yield_summary_statistics.xlsx")

# ALternatyva: eksportuojame ir žalius duomenis, į rezultatus į atskirus lapus
write_xlsx(list(
  raw_data = yield_data,
  summary_statistics = summary_df
), "yield_analysis_complete.xlsx")


# ===== Alternatyva: galima naudoti xlsx paketą (naudoja Java) =====
# install.packages("xlsx")
library(xlsx)

# Eksportuojame tik rezultatus
write.xlsx(summary_df, "yield_summary_statistics_v2.xlsx",
           sheetName = "Summary", row.names = FALSE)

# Eksportuojame daug Excel lapų
wb <- createWorkbook()
sheet1 <- createSheet(wb, sheetName = "Raw Data")
sheet2 <- createSheet(wb, sheetName = "Summary Statistics")
addDataFrame(yield_data, sheet1, row.names = FALSE)
addDataFrame(summary_df, sheet2, row.names = FALSE)
saveWorkbook(wb, "yield_analysis_complete_v2.xlsx")
