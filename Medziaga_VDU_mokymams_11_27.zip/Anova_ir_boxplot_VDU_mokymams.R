################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

# Naudosime chickwts duomenų rinkinį
?chickwts
head(chickwts)
View(chickwts)

# Susikuriam pogrupius tam, kad galėtume 
# patikrinti duomenų normalumą
# atskirai kiekviename pogrupyje
horsebean<-subset(chickwts,chickwts$feed == "horsebean")
linseed<-subset(chickwts,chickwts$feed == "linseed")
soybean<-subset(chickwts,chickwts$feed == "soybean")
sunflower<-subset(chickwts,chickwts$feed == "sunflower")
meatmeal<-subset(chickwts,chickwts$feed == "meatmeal")
casein<-subset(chickwts,chickwts$feed == "casein")

# Pasitikriname duomenų normalumą
shapiro.test(horsebean$weight)
shapiro.test(linseed$weight)
shapiro.test(soybean$weight)
shapiro.test(sunflower$weight)
shapiro.test(meatmeal$weight)
shapiro.test(casein$weight)

# Arba jeigu turime daug grupių ir nenorime tikrinti po vieną:
by(chickwts$weight, chickwts$feed, shapiro.test)

# Pasitikriname dispersijų homogeniškumą
if (!require("car")) install.packages("car")
library(car)

leveneTest(weight ~ feed, data = chickwts)

# Atliekame ANOVA (jeigu duomenys normalūs ir dispersijos homogeniškos)
anova_result <- aov(weight ~ feed, data = chickwts)
summary(anova_result)

# Patikriname ANOVA residuals (liekanų) normalumą
residuals_anova <- residuals(anova_result)
shapiro.test(residuals_anova)

# Atliekame Tukey's HSD testą
TukeyHSD(anova_result)

# Sukuriame raides, kurios parodo reikšmingus skirtumus
if (!require("agricolae")) install.packages("agricolae")
library(agricolae)
hsd_res <- HSD.test(anova_result, "feed", group = TRUE)
hsd_res

####################################
# Alternatyvūs statistiniai testai #
##### pagal duomenų normalumą ######
### ir dispersijų homogeniškumą ####
####################################

# Atliekame ANOVA su Welch korekcija
# (jeigu duomenys normalūs ir dispersijos nehomogeniškos)
welch_anova <- oneway.test(weight ~ feed, data = chickwts, var.equal = FALSE)
welch_anova

# Atliekame Kruskal-Wallis testą
# (jeigu duomenys nėra pasiskirstę normaliai)
kruskal_test <- kruskal.test(weight ~ feed, data = chickwts)
kruskal_test

###########################
# Vizualizuojame duomenis #
###########################

# 1. Base R dėžučių diagrama
boxplot(weight ~ feed,
        data = chickwts,
        col = c("#5C4B99", "#9AA0FF","#EABFFF", 
                "#7ED3FF", "#3EA6FF", "#286DA8"),
        border = "grey40",
        main = "Chicken Weight by Feed Type (Base R)",
        xlab = "Feed Type",
        ylab = "Weight (g)",
        las = 1,
        cex.axis = 0.8,
        cex.lab = 1.1,
        cex.main = 1.3)

grid(nx = NA, ny = NULL, col = "grey85", lty = 1)


# 2. Paprasta ggplot2 diagrama
library(ggplot2)

p1 <- ggplot(chickwts, aes(x = feed, y = weight, fill = feed)) +
  geom_boxplot(alpha = 0.9, color = "grey30", linewidth = 0.5) +
  scale_fill_manual(values = c("#5C4B99", "#9AA0FF","#EABFFF", 
                               "#7ED3FF", "#3EA6FF", "#286DA8")) +
  labs(title = "Chicken Weight by Feed Type (ggplot2 v.1)",
       x = "Feed Type",
       y = "Weight (g)") +
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none",
    panel.grid.minor = element_blank()
  ) +
  scale_y_continuous(limits = c(100,450), breaks = seq(100,450,50))

p1

# 3. Patobulinta ggplot2 diagrama
if (!require("multcompView")) install.packages("multcompView")
library(ggplot2)
library(dplyr)
library(multcompView)

# "Išsitraukiame" originalų grupių eiliškumą
original_levels <- levels(chickwts$feed)

# Ta pačia tvarka sudėliojame tuos pačius pavadinimus iš didžiųjų raidžių:
capitalised_labels <- tools::toTitleCase(original_levels)

# Sukuriame grupių eiliškumą
feed_order <- c("horsebean", "linseed", "soybean", 
                "meatmeal", "sunflower", "casein")

# Pakeičiame eiliškumą ir pakoreguojame pavadinimus
chickwts2 <- chickwts %>%
  mutate(
    feed = factor(feed,
                  levels = feed_order,           # reordering
                  labels = tools::toTitleCase(feed_order))  # renaming
  )

# Atliekame ANOVA testą
anova_result <- aov(weight ~ feed, data = chickwts2)
anova_summary <- summary(anova_result)
p_value <- anova_summary[[1]][["Pr(>F)"]][1]

# Atliekame Tukey's HSD testą
tukey_result <- TukeyHSD(anova_result)

# Pasiimame post hoc raidžių duomenis
tukey_letters <- multcompLetters4(anova_result, tukey_result)

# Priskiriame kiekvienai lesalo grupei raidę
letters_df <- data.frame(
  feed = names(tukey_letters$feed$Letters),
  letters = tukey_letters$feed$Letters
)

# Apskaičiuojame max svorį kiekvienoje svorio kategorijoje
# Kad teisingai nustatytume post hoc raidžių vietą
max_weights <- chickwts2 %>%
  group_by(feed) %>%
  summarise(max_weight = max(weight)) %>%
  left_join(letters_df, by = "feed")

# Brėžiame grafiką
p2 <- ggplot(chickwts2, aes(x = feed, y = weight, fill = feed)) +
  geom_boxplot(alpha = 0.9, color = "grey30", linewidth = 0.5) +
  scale_fill_manual(values = c("#5C4B99", "#9AA0FF","#EABFFF", 
                               "#7ED3FF", "#3EA6FF", "#286DA8")) +
  # Pridedame Tukey HSD raides
  geom_text(data = max_weights, 
            aes(x = feed, y = max_weight + 15, label = letters),
            vjust = 0, size = 5, fontface = "bold") +
  labs(
    title = "Chicken Weight by Feed Type (ggplot2 v.2)",
    subtitle = paste0("ANOVA: p ", 
                      ifelse(p_value < 0.001, "< 0.001", 
                             paste("=", round(p_value, 3))),
                      " | Letters indicate differences between groups (Tukey's HSD, p < 0.05)"),
    x = "Feed Type",
    y = "Weight (g)"
  ) +
  theme_bw(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    plot.subtitle = element_text(size = 12, color = "grey30"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position
    = "none"
  ) +
  # Išplečiame y ašį, kad tilptų raidės
  scale_y_continuous(limits = c(100,450), breaks = seq(100,450,50)) +
  theme(plot.subtitle=element_text(size=9))
p2

# Išsaugome grafiką su 300 dpi nustatymu
# (prisiminkite, kur jūsų darbinė direktorija - nusistatykite ją)
setwd("C:/Users/gabij/Documents/Biomatika/Mokymai/VDU_2026_11_20")
getwd()

ggsave("chickwts_2.png", p2, 
       width = 6, height = 5, dpi = 300, units = "in")
