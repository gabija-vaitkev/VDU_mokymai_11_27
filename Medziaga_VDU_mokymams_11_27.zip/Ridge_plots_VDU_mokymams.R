################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

# Užkrauname paketus. Jei paketai nesudiegti,
# pirmiau juos reikia sudiegti.
# install.packages("ggridges")

library(ggplot2)
library(ggridges)

# informacija apie ridge plots
browseVignettes("ggridges")

# ggridges::lincoln_weather		Weather in Lincoln, Nebraska in 2016.

# Užkrauname duomenų failą
# lincoln_weather <- ggridges::lincoln_weather

View(lincoln_weather)

# Grafiko kodas
ggplot(lincoln_weather, aes(x = `Mean Temperature [F]`, y = Month, fill = after_stat(x))) +
  geom_density_ridges_gradient(scale = 3, rel_min_height = 0.01, gradient_lwd = 1.) +
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_discrete(expand = expansion(mult = c(0.01, 0.25))) +
  scale_fill_viridis_c(name = "Temp. [F]", option = "C") +
  labs(
    title = 'Temperatures in Lincoln NE',
    subtitle = 'Mean temperatures (Fahrenheit) by month for 2016'
  ) +
  theme_ridges(font_size = 13, grid = TRUE) + 
  theme(axis.title.y = element_blank())
