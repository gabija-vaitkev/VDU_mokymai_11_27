################################
##### Statistikos mokymai ######
### Dr. Gabija Vaitkevičiūtė ###
###### info@biomatika.lt #######
################################

# Sudiegiame ir užkrauname reikiamus paketus
# install.packages("ggplot2")  
# install.packages("reshape2")
library(ggplot2)
library(reshape2)

# ===== 1 PAVYZDYS: Paprastas Heatmap - Genų raiška tarp skirtingų grupių =====

# Sukuriame sintetinius genų raiškos duomenis
set.seed(123)
genes <- paste0("Gene_", 1:10)
treatments <- c("Control", "Drought", "Heat", "Salt", "Combined")

# Sugeneruojame genų raiškos vertes  (fold change)
expression_matrix <- matrix(
  runif(50, min = -5, max = 5),
  nrow = 10,
  ncol = 5,
  dimnames = list(genes, treatments)
)

# Konvertuojame matricą į "ilgą" formatą, skirtą ggplot2
expression_long <- melt(expression_matrix)
colnames(expression_long) <- c("Gene", "Treatment", "Expression")

# Pasižiūrime duomenis
head(expression_long)

# Sukuriame paprastą heatmap
ggplot(expression_long, aes(x = Treatment, y = Gene, fill = Expression)) +
  geom_tile(color = "white", linewidth = 0.5) +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint = 1, name = "Fold Change") +
  labs(title = "Gene Expression Under Different Stress Conditions",
       x = "Treatment",
       y = "Gene") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(size = 14, face = "bold"))


# ===== 2 PAVYZDYS: Azoto koncentracija dirvoje skirtinguose laukeliuose =====

# Sukuriame sintetinius dirvos duomenis (išdėstymas laukeliais)
set.seed(456)
rows <- paste0("Row_", 1:6)
columns <- paste0("Col_", 1:8)

# Sukuriame azoto koncentracijas (ppm)
nitrogen_data <- expand.grid(Row = rows, Column = columns)
nitrogen_data$Nitrogen <- rnorm(48, mean = 45, sd = 12)

# Sukuriame heatmap su pasirenkama spalvų skale
ggplot(nitrogen_data, aes(x = Column, y = Row, fill = Nitrogen)) +
  geom_tile(color = "gray50", linewidth = 0.3) +
  geom_text(aes(label = round(Nitrogen, 0)), color = "black", size = 3) +
  scale_fill_gradient(low = "lightyellow", high = "darkgreen", 
                      name = "N (ppm)") +
  labs(title = "Soil Nitrogen Distribution Across Field",
       subtitle = "Values shown in ppm",
       x = "Column",
       y = "Row") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(size = 14, face = "bold"),
        panel.grid = element_blank())


# ===== 3 PAVYZDYS: ligos pasireiškimo stiprumas per laiką skirtingose veislėse =====

# Sukuriame sintetinius duomenis (ligos progresavimas)
set.seed(321)
varieties <- paste0("Variety_", LETTERS[1:5])
weeks <- paste0("Week_", 1:8)

# Sugeneruojame ligos vertinimo balus (0-100%)
disease_matrix <- matrix(
  nrow = 5,
  ncol = 8,
  dimnames = list(varieties, weeks)
)

# Sukuriame ligos progresavimą (per laiką stiprėja)
for (i in 1:5) {
  base_resistance <- runif(1, 10, 30)
  for (j in 1:8) {
    disease_matrix[i, j] <- min(100, base_resistance + j * runif(1, 5, 12))
  }
}

# Konvertuojame į ilgą formatą
disease_long <- melt(disease_matrix)
colnames(disease_long) <- c("Variety", "Week", "Severity")

# Sukuriame heatmap
ggplot(disease_long, aes(x = Week, y = Variety, fill = Severity)) +
  geom_tile(color = "white", linewidth = 0.5) +
  geom_text(aes(label = round(Severity, 0)), color = "white", size = 3.5) +
  scale_fill_gradient(low = "green", high = "darkred", 
                      name = "Severity (%)") +
  labs(title = "Disease Progression Across Wheat Varieties",
       subtitle = "Fusarium head blight severity over 8 weeks",
       x = "Time Point",
       y = "Variety") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(size = 14, face = "bold"),
        panel.grid = element_blank())


# ===== 4 PAVYZDYS: pheatmap paketas (Hierarchical Clustering) =====

# install.packages("pheatmap")
library(pheatmap)

# Panaudojame genų raiškos duomenis iš 1 pavyzdžio
# pheatmap automatiškai sudeda eiles ir stulpelius į "klasterius"
pheatmap(expression_matrix,
         color = colorRampPalette(c("blue", "white", "red"))(100),
         main = "Gene Expression with Hierarchical Clustering",
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         show_rownames = TRUE,
         show_colnames = TRUE,
         fontsize = 10,
         angle_col = 45)

# Eksportuojame heatmap į failą 
pdf("gene_expression_heatmap.pdf", width = 8, height = 6)
pheatmap(expression_matrix,
         color = colorRampPalette(c("blue", "white", "red"))(100),
         main = "Gene Expression with Hierarchical Clustering",
         cluster_rows = TRUE,
         cluster_cols = TRUE,
         show_rownames = TRUE,
         show_colnames = TRUE,
         fontsize = 10,
         angle_col = 45)

dev.off()
cat("Heatmap saved to gene_expression_heatmap.pdf\n")
